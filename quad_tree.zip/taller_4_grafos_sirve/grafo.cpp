#include "grafo.h"

template <class T>
bool insertarVertice(Grafo<T> &grafo, T dato)
{
    vector<Aux <T> > aristas;
	  grafo.vertices.push_back(dato);
	  grafo.aristas.push_back(aristas);
}

template <class T>
bool insertarArista(Grafo<T> &grafo, T datoS, T datoF, int peso)
{
    int posI, cont = 0;

    for(int i = 0; i < grafo.vertices.size(); i++)
    {
        if(grafo.vertices[i] == datoS)
        {
            posI = i;
            cont++;
        }
        if(grafo.vertices[i] == datoF)
        {
            cont++;
        }
    }

    if(cont!=2)
    {
        return false;
    }

    Aux<T> aux;
    aux.dato = datoF;
    aux.peso = peso;

    for(int i = 0; i < grafo.aristas[posI].size() && cont == 2; i++)
    {
        if(grafo.aristas[posI][i].dato == datoF)
        {
            return false;
        }
    }

    grafo.aristas[posI].push_back(aux);
    return true;
}

template <class T>
bool eliminarVertice(Grafo<T> &grafo, T dato)
{

    bool elimino = false;
    int pos;

    for(int i = 0; i < grafo.vertices.size() && !elimino; i++)
    {
        if(grafo.vertices[i] == dato)
        {
            grafo.vertices.erase(grafo.vertices.begin() + i);
            pos = i;
            elimino = true;
        }
    }

    if(!elimino)
    {
        return false;
    }

    grafo.arista.erase(grafo.arista.begin()+pos);

    for(int i = 0; i < grafo.aristas.size(); i++)
    {
        elimino = false;

        for(int j = 0; j < grafo.arista[i].size() && !elimino ; j++)
        {
            if(grafo.arista[i][j].dato == dato)
            {
                grafo.arista[i].erase(grafo.arista[i].begin() + j);
                elimino = true;
            }
        }
    }

    return true;
}

template <class T>
bool eliminarArista(Grafo<T> &grafo, T datoS, T datoF)
{

    bool elimino = false, encontro = false;
    int posI, cont = 0;

    for(int i = 0; i < grafo.vertices.size(); i++)
    {
        if(grafo.vertices[i] == datoS)
        {
            posI = i;
            cont++;
        }
        if(grafo.vertices[i] == datoF)
        {
            cont++;
        }
    }

    if(cont != 2)
    {
        return false;
    }

    for(int i = 0; i < grafo.arista[posI].size() && !elimino ; i++)
    {
        if(grafo.arista[posI][i].dato == datoF)
        {
            grafo.arista[posI].erase(grafo.arista[posI].begin() + i);
            return true;
        }
    }

    return false;
}

template <class T>
bool buscarVertice(Grafo<T> grafo, T dato)
{
    for(int i = 0; i < grafo.vertices.size(); i++)
    {
        if(grafo.vertices[i] == dato)
        {
            return true;
        }
    }

    return false;
}

template <class T>
bool buscarArista(Grafo<T> grafo, T datoS, T datoF)
{
   int posI, cont = 0;

    for(int i = 0; i < grafo.vertices.size(); i++)
    {
        if(grafo.vertices[i] == datoS)
        {
            posI = i;
            cont++;
        }
        if(grafo.vertices[i] == datoF)
        {
            cont++;
        }
    }

    if(cont != 2)
    {
        return false;
    }

    for(int i = 0; i < grafo.aristas[posI].size() && cont == 2; i++)
    {
        if(grafo.aristas[posI][i].dato == datoF)
        {
            return true;
        }
    }

    return false;
}

template <class T>
int cantidadVertices(Grafo<T> grafo)
{
    return grafo.vertices.size();
}

template <class T>
int cantidadAristas(Grafo<T> grafo)
{
    int acumulador = 0;

    for(int i = 0; i < grafo.aristas.size(); i++)
    {
        acumulador += grafo.aristas[i].size();
    }

    return acumulador;
}

template <class T>
bool esVacio(Grafo<T> grafo)
{
    return (!cantidadVertices(grafo) && !cantidadAristas(grafo));
}

template <class T>
void recorridoProfundidad(Grafo<T> grafo, T verticeOrigen, vector<T> &visitados)//DFS
{
    int pos = -1;

    for(int i = 0; i < grafo.vertices.size(); i++)
    {
        if (grafo.vertices[i] == verticeOrigen)
        {
            cout << verticeOrigen << '\n';
            visitados.push_back(verticeOrigen);
            pos = i;
            break;
        }
    }

    if (pos > 0)
    {
        for(int i = 0; i < grafo.aristas[pos].size(); i++)
        {
            bool sw = 0;
            int pos2;

            for (int j = 0; j < visitados.size(); j++)
            {
                if (visitados[j] == grafo.arista[pos][i].dato)
                {
                    pos2 = i;
                    sw = 1;
                    break;
                }
            }

            if (!sw)
            {
                recorridoProfundidad(grafo, grafo.arista[pos][pos2].dato, visitados);
            }
        }
    }
}

template <class T>
void recorridoAnchura(Grafo<T> grafo, T verticeOrigen, vector<T> visitados)//BFS
{
    queue<T> cola;
    cola.push(verticeOrigen);

    while (!cola.empty())
    {
        T  aux = cola.pop();
        cout << aux << '\n';
        bool sw = 0;

        for (int i = 0; i < visitados.size(); i++)
        {
            if (visitados[i] == aux)
            {
                sw = 1;
                break;
            }
        }

        if (!sw)
        {
            visitados.push_back(aux);
            int pos;

            for (int i = 0; i < grafo.vertices.size(); i++)
            {
                if (grafo.vertices[i] == aux)
                {
                    pos = i;
                    break;
                }
            }

            for (int i = 0; i < grafo.aristas[pos].size(); i++)
            {
                cola.push(grafo.aristas[pos][i].dato);
            }
        }
    }
}

template <class T>
int componentesConectados(Grafo<T> grafo, T verticeOrigen)
{
    vector<T> visitados;
    recorridoProfundidad(grafo, verticeOrigen, visitados);

    if (visitados.size() == grafo.vertices.size())
    {
        return 1;
    }
    else
    {
        bool esta;
        int cont = 1;//porque ya encontro 1

        for (int i = 0; i < grafo.vertices.size(); i++)
        {
            esta = 0;

            for (int j = 0; j < visitados.size(); j++)
            {
                if (grafo.vertices[i] == visitados[i])
                {
                    esta = 1;
                    break;
                }
            }

            if (!esta)
            {
                recorridoProfundidad(grafo, grafo.vertices[i], visitados);
                cont++;
            }
        }

        return cont;
    }
}

template <class T>
void aristasPuente(Grafo<T> grafo, T verticeOrigen, vector<Aux2 <T> > &aristasPuente)
{
    Grafo<T> grafo2 = grafo;
    int numComponentes = componentesConectados(grafo, grafo.vectice[0]);

    for (int i = 0; i < grafo2.aristas.size(); i++)
    {
        for (int j = 0; j < grafo2.aristas[i].size(); j++)
        {
            eliminarArista(grafo2, grafo2.vertices[i], grafo2.aristas[i][j].dato);

            if (componentesConectados(grafo2, grafo2.vertices[0]) > numComponentes)
            {
                Aux2<T> puente;
                puente.datoS = grafo.vertices[i];
                puente.datoF = grafo.aristas[i][j].dato;
                aristasPuente.push_back(puente);
            }

            grafo2 = grafo;
        }
    }
}

template <class T>
void caminoEuler(Grafo<T> grafo, T verticeOrigen)
{
    if (componentesConectados(grafo, grafo.vertices[0]) == 1)
    {
        int cont = 0, pos;

        for (int i = 0; i < grafo.aristas.size(); i++)
        {
            if (grafo.aristas.size() % 2 != 0)
            {
                pos = i;
                cont++;
            }
        }

        if (cont == 2 || cont == 0)
        {
            vector<Aux2 <T> > aristasPuente;
            vector<Aux2 <T> > visitados;
            aristasPuente(grafo, grafo.vertices[0], aristasPuente);

            if (cont == 2)
            {
                algoritmoFleury(grafo, grafo.vertices[pos], visitados, aristasPuente);
            }
            else
            {
                algoritmoFleury(grafo, grafo.vertices[0], visitados, aristasPuente);
            }
        }
    }
}

template <class T>
void algoritmoFleury(Grafo<T> grafo, T verticeOrigen, vector<Aux2 <T> > &visitados, vector<Aux2 <T> > aristasPuente)
{
    int pos = -1;

    for(int i = 0; i < grafo.aristas.size(); i++)
    {
        if (grafo.vertices[i] == verticeOrigen)
        {
            for (int j = 0; j < grafo.aristas[i].size(); j++)
            {
                bool esta = 0;

                for (int k = 0; k < visitados.size(); k++)
                {
                    if (grafo.vertices[i] == visitados[k].datoS && grafo.aristas[i][j].dato == visitados[k].datoS)
                    {
                        esta = 1;
                        break;
                    }
                }

                if (!esta)
                {
                    cout << verticeOrigen << '\n';
                    Aux2<T> visitado;
                    visitado.datoS = grafo.vertices[i];
                    int pos;

                    for (int k = 0; k < aristasPuente.size(); k++)
                    {
                        if (grafo.vertices[i] == aristasPuente[k].datoS && grafo.aristas[i][j].dato == aristasPuente[k].datoS)
                        {
                            bool op = 0;

                            for (int l = 0; l < grafo.aristas[i].size(); l++)
                            {
                                op = 1;

                                for (int m = 0; m < visitados.size(); m++)
                                {
                                    if (l != j)
                                    {
                                        if (grafo.vertices[i] == visitados[m].datoS && grafo.aristas[i][l] == visitados[m].datoS)
                                        {
                                            op = 0;
                                            break;
                                        }
                                    }
                                }

                                if (op)
                                {
                                    visitado.datoF = grafo.aristas[i][l].dato;
                                    pos = l;
                                    break;
                                }
                            }

                            if (!op)
                            {
                                visitado.datoF = grafo.aristas[i][j].dato;
                                pos = j;
                                break;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }

                    visitados.push_back(visitado);
                    algoritmoFleury(grafo, grafo.vertices[pos], visitados, aristasPuente);
                }
            }
        }
    }
}

template <class T>
void algoritmoPrim(Grafo<T> grafo, T verticeOrigen)
{
    vector<T> ant;
    deque<T> verticesVisitados;
    deque<Aux2 <T> > aristas;
    verticesVisitados.push_back(verticeOrigen);
    Aux2<T> origen;
    origen.datoS = verticeOrigen;
    origen.datoF = verticeOrigen;
    origen.peso = 0;
    aristas.push_back(origen);
    ant.push_back(verticeOrigen);

    while (verticesVisitados.size() != grafo.vertice.size())
    {
        //escoger arista {u,v} con peso mínimo, u debe estar en Vnew y v no
        for (int i = 0; i < verticesVisitados.size(); i++)
        {
            int men = 10000;
            T u = verticesVisitados[i];

            if (verticesVisitados[i] == u)
            {
                for (int j = 0; j < grafo.arista[i].size(); i++)
                {
                    bool esta = 0;

                    for (int k = 0 ; k < verticesVisitados.size(); k++)
                    {
                        if (verticesVisitados[k] == grafo.arista[i][j].dato)
                        {
                            esta = 1;
                            break;
                        }
                    }

                    if (!esta)
                    {
                        if (grafo.arista[i][j].peso < men)
                        {
                            men = grafo.arista[i][j].peso;
                            origen.datoS = u;
                            origen.datoF = grafo.arista[i][j].dato;
                            origen.peso = grafo.arista[i][j].peso;
                        }
                    }
                }
            }
        }

        verticesVisitados.push_back(origen.datoF);
        ant.push_back(origen.datoS);
        aristas.push_back(origen);
    }
}

template <class T>
vector<long> algoritmoDijkstra(Grafo<T> grafo, long verticeOrigen)
{
    deque<long> s, q;
    vector<float> dist;
    vector<bool> vivoQ;
    vector<long> antecesores;

    for (int i = 0; i < grafo.vertices.size(); i++)
    {
        antecesores.push_back(verticeOrigen);
        dist.push_back(0);
        vivoQ.push_back(1);
	q.push_back(i);
    }

    for (int i = 0; i < grafo.vertices.size(); i++)
    {
        if (verticeOrigen == i)
        {
            dist[i] = 0;
        }
        else
        {
           dist[i] = 10000;
        }
    }

    while(s.size() != grafo.vertices.size())
    {
        int min = buscarMenor(dist, vivoQ);
				//cout << "Soy el minimo " << min << endl << endl;
        s.push_back(min);

        for (int j = 0; j < grafo.aristas[min].size(); j++)
        {
		int pos;

			for (int k = 0; k < grafo.vertices.size(); k++)
			{
				if (grafo.vertices[k]== grafo.aristas[min][j].dato)
				{
						pos = k;
						break;
				}
			}

            if (dist[pos] > dist[min] + grafo.aristas[min][j].peso)
            {
                        dist[pos] = dist[min] + grafo.aristas[min][j].peso;
                        antecesores[pos] = min;
            }
        }
    }

		/*for (int i = 0; i < grafo.vertices.size(); i++)
		{
				cout << dist[i] << " " << antecesores[i] << " " << q[i] << " " << vivoQ[i] <<  endl << endl;
		}*/
		return antecesores; //dist
}


int buscarMenor(vector<float> dist, vector<bool> &vivoQ)
{
    float men = 10000, pos;

    for (int i = 0; i < dist.size(); i++)
    {
        if (dist[i] < men && vivoQ[i])
        {
            pos = i;
		men = dist[i];
        }
    }
    vivoQ[pos] = 0;
	return pos;
}

template <class T>
void convertirNegativos_Positivos(Grafo<T> &g)
{
    float menor = 10000;
    for(int i = 0; i<g.aristas.size(); i++)
    {
        for(int j=0; j<g.aristas[i].size(); j++)
        { 
            if(g.aristas[i][j].peso < menor)
            {
                menor= g.aristas[i][j].peso;
            }
        }
    }
    
    for(int i = 0; i<g.aristas.size(); i++)
    {
        for(int j=0; j<g.aristas[i].size(); j++)
        {
            g.aristas[i][j].peso += ((-1)*menor)+1;
        }
    }
}

