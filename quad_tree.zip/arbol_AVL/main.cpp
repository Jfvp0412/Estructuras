//g++ -std=c++11 -o hola main.cpp
#include <iostream>
#include "arbol.h"

using namespace std;

int main()
{
    Arbol<int> tree;
    tree.raiz = NULL;
    crearArbol(tree, 7);

    insertarNodo(tree.raiz, 7);
    insertarNodo(tree.raiz, 3);
    insertarNodo(tree.raiz, 20);
    insertarNodo(tree.raiz, 0);
    insertarNodo(tree.raiz, 5);
    insertarNodo(tree.raiz, 15);
    insertarNodo(tree.raiz, 25);
    insertarNodo(tree.raiz, 1);
    insertarNodo(tree.raiz, 4);
    insertarNodo(tree.raiz, 6);
    insertarNodo(tree.raiz, 30);
    insertarNodo(tree.raiz, 35);

    nivelOrden(tree.raiz);
    cout << "La altura del arbol es: " << altura(tree.raiz) << '\n';
}
