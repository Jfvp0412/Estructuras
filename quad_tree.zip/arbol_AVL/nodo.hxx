#include "nodo.h"

template< class T >
void insetarLeft(Nodo<T> *nodo, T nval)
{
    Nodo<T> *nuevo = new Nodo<T>();
    nuevo->dato = nval;
    nuevo->left = NULL;
    nuevo->right = NULL;
    nodo->left = nuevo;
    if (altura(inicio->left) - altura(inicio->right) == 2)
    {
        if (n < inicio->left->dato)
        {
            std::cout << "/* message1 */" << '\n';
            inicio = rotacionAIzquierda(inicio);
        }
        else
        {
            std::cout << "/* message2 */" << '\n';
            inicio = rotacionDobleIzquierda(inicio);
        }
    }
}

template< class T >
void insertarRight(Nodo<T> *nodo, T nval)
{
    Nodo<T> *nuevo = new Nodo<T>();
    nuevo->dato = nval;
    nuevo->left = NULL;
    nuevo->right = NULL;
    nodo->right = nuevo;
}

template< class T >
void eliminar(Nodo<T> *nodo)
{
    delete(nodo);
}
