//g++ -std=c++11 -o hola main.cpp
#include <iostream>
#include "arbol.h"

using namespace std;

int main()
{
    Arbol<int> tree;
    tree.raiz = NULL;
    crearArbol(tree, 32, 25);

    insertarNodo(tree.raiz, 30, 35, 0);
    insertarNodo(tree.raiz, 35, 30, 0);
    insertarNodo(tree.raiz, 37, 12, 0);
    insertarNodo(tree.raiz, 25, 45, 0);
    insertarNodo(tree.raiz, 45, 32, 0);
    insertarNodo(tree.raiz, 5, 15, 0);
    insertarNodo(tree.raiz, 40, 42, 0);
}
