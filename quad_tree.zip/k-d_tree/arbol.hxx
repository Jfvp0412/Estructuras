#include "arbol.h"

template< class T >
void crearArbol(Arbol<T> &tree, T val, T val2)
{
    tree.raiz = new Nodo<T>();
    tree.raiz->dato = val;
    tree.raiz->dato2 = val2;
    tree.raiz->left = NULL;
    tree.raiz->right = NULL;
}

template< class T >
bool esVacio(Nodo<T> *inicio)
{
    return inicio == NULL;
}

template< class T >
Nodo<T>* buscarNodoMay(Nodo<T> *inicio)
{
    Nodo<T> *may = NULL, *aux = inicio;

    while (aux != NULL)
    {
        may = aux;
        aux = aux->right;
    }

    return may;
}

template< class T >
bool insertarNodo(Nodo<T> *inicio, T n, T n2, int dim)
{
    if (!esVacio(inicio))
    {

        if (dim % 2 == 0)
        {
            if (inicio->dato == n)
            {
                return false;
            }
            else if (n < inicio->dato)
            {

                if (inicio->left == NULL)
                {
                    insetarLeft(inicio, n, n2);
                    return true;
                }
                else
                {
                    dim++;
                    cout << "Estoy en x y en left " << dim << endl;
                    return insertarNodo(inicio->left, n, n2, dim);
                }
            }
            else
            {
                if (inicio->right == NULL)
                {
                    insertarRight(inicio, n, n2);
                    return true;
                }
                else
                {
                    dim++;
                    cout << "Estoy en x y en right " << dim << endl;
                    return insertarNodo(inicio->right, n, n2, dim);
                }
            }
        }
        else
        {
            if (inicio->dato2 == n2)
            {
                return false;
            }
            else if (n2 < inicio->dato2)
            {
                if (inicio->left == NULL)
                {
                    insetarLeft(inicio, n, n2);
                    return true;
                }
                else
                {
                    dim++;
                    cout << "Estoy en y y en left " << dim << endl;
                    return insertarNodo(inicio->left, n, n2, dim);
                }
            }
            else
            {
                if (inicio->right == NULL)
                {
                    insertarRight(inicio, n, n2);
                    return true;
                }
                else
                {
                    dim++;
                    cout << "Estoy en y y en right " << dim << endl;
                    return insertarNodo(inicio->right, n, n2, dim);
                }
            }
        }
    }
}

template< class T >
bool eliminarNodo(Nodo<T> *inicio, Nodo<T> *anterior, T &n, T &n2, int dim)
{
    if (!esVacio(inicio))
    {
        if (dim % 2 == 0)
        {
            if (inicio->dato == n && inicio->dato2 == n2)
            {
                if (inicio->left == NULL && inicio->right == NULL)
                {
                    if (anterior->left != NULL)
                    {
                        if (anterior->left->dato == n)
                        {
                            anterior->left = NULL;
                        }
                        else
                        {
                            anterior->right = NULL;
                        }
                    }
                    else if (anterior->right != NULL)
                    {
                        if (anterior->right->dato == n)
                        {
                            anterior->right = NULL;
                        }
                        else
                        {
                            anterior->left = NULL;
                        }
                    }

                    eliminar(inicio);
                    return true;
                }
                else if (inicio->left != NULL && inicio->right != NULL)
                {
                    Nodo<T> *may = buscarNodoMay(inicio->left);
                    int temp = may->dato;
                    int temp2 = may->dato2;
                    eliminarNodo(anterior, anterior, temp, temp2, 0);
                    inicio->dato = temp;
                    inicio->dato2 = temp2;
                    return true;
                }
                else
                {
                    if (inicio->left != NULL)
                    {
                        int temp = inicio->left->dato;
                        int temp2 = inicio->left->dato2;
                        inicio->dato = temp;
                        inicio->dato2 = temp2;
                        inicio->left = NULL;
                        return true;
                    }
                    else
                    {
                        int temp = inicio->right->dato;
                        int temp2 = inicio->right->dato2;
                        inicio->dato = temp;
                        inicio->dato2 = temp2;
                        inicio->right = NULL;
                        return true;
                    }
                }
            }
            else if (n < inicio->dato)
            {
                if (inicio->left != NULL)
                {
                    dim++;
                    return eliminarNodo(inicio->left, inicio, n, n2, dim);
                }
            }
            else
            {
                if (inicio->right != NULL)
                {
                    dim++;
                    return eliminarNodo(inicio->right, inicio, n, n2, dim);
                }
            }
        }
        else
        {
            if (inicio->dato == n && inicio->dato2 == n2)
            {
                if (inicio->left == NULL && inicio->right == NULL)
                {
                    if (anterior->left != NULL)
                    {
                        if (anterior->left->dato2 == n2)
                        {
                            anterior->left = NULL;
                        }
                        else
                        {
                              anterior->right = NULL;
                        }
                    }
                    else if (anterior->right != NULL)
                    {
                        if (anterior->right->dato2 == n2)
                        {
                            anterior->right = NULL;
                        }
                        else
                        {
                              anterior->left = NULL;
                        }
                    }

                    eliminar(inicio);
                    return true;
                }
                else if (inicio->left != NULL && inicio->right != NULL)
                {
                    Nodo<T> *may = buscarNodoMay(inicio->left);
                    int temp = may->dato;
                    int temp2 = may->dato2;
                    eliminarNodo(anterior, anterior, temp, temp2, 0);
                    inicio->dato = temp;
                    inicio->dato2 = temp2;
                    return true;
                }
                else
                {
                    if (inicio->left != NULL)
                    {
                        int temp = inicio->left->dato;
                        int temp2 = inicio->left->dato2;
                        inicio->dato = temp;
                        inicio->dato2 = temp2;
                        inicio->left = NULL;
                        return true;
                    }
                    else
                    {
                        int temp = inicio->right->dato;
                        int temp2 = inicio->right->dato2;
                        inicio->dato = temp;
                        inicio->dato2 = temp2;
                        inicio->right = NULL;
                        return true;
                    }
                }
            }
            else if (n2 < inicio->dato2)
            {
                if (inicio->left != NULL)
                {
                    dim++;
                    return eliminarNodo(inicio->left, inicio, n, n2, dim);
                }

            }
            else
            {
                if (inicio->right != NULL)
                {
                    dim++;
                    return eliminarNodo(inicio->right, inicio, n, n2, dim);
                }
            }
        }
    }

    return false;
}

template< class T >
bool buscar(Nodo<T> *inicio, T n, T n2, int dim)
{
    if (!esVacio(inicio))
    {
        if (dim % 2 == 0)
        {
            if (inicio->dato == n && inicio->dato2 == n2)
            {
                return true;
            }
            else if (n < inicio->dato)
            {
                if (inicio->left != NULL)
                {
                    dim++;
                    return buscar(inicio->left, n, n2, dim);
                }
            }
            else
            {
                if (inicio->right != NULL)
                {
                    dim++;
                    return buscar(inicio->right, n, n2, dim);
                }
            }
        }
        else
        {
            if (inicio->dato == n && inicio->dato2 == n2)
            {
                return true;
            }
            else if (n2 < inicio->dato2)
            {
                if (inicio->left != NULL)
                {
                    dim++;
                    return buscar(inicio->left, n, n2, dim);
                }
            }
            else
            {
                if (inicio->right != NULL)
                {
                    dim++;
                    return buscar(inicio->right, n, n2, dim);
                }
            }
        }
    }

    return false;
}

template< class T >
void nivelOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        queue<Nodo<T>*> q;
        q.push(inicio);

        while (!q.empty())
        {
              Nodo<T> *temp = q.front();
              q.pop();
              cout << temp->dato << " " << temp->dato2 << '\n';

              if (temp->left != NULL)
              {
                  q.push(temp->left);
              }
              if (temp->right != NULL)
              {
                  q.push(temp->right);
              }
        }
    }
}
