#include "nodo.h"

template< class T >
void insetarLeft(Nodo<T> *nodo, T nval, T nval2)
{
    Nodo<T> *nuevo = new Nodo<T>();
    nuevo->dato = nval;
    nuevo->dato2 = nval2;
    nuevo->left = NULL;
    nuevo->right = NULL;
    nodo->left = nuevo;
}

template< class T >
void insertarRight(Nodo<T> *nodo, T nval, T nval2)
{
    Nodo<T> *nuevo = new Nodo<T>();
    nuevo->dato = nval;
    nuevo->dato2 = nval2;
    nuevo->left = NULL;
    nuevo->right = NULL;
    nodo->right = nuevo;
}

template< class T >
void eliminar(Nodo<T> *nodo)
{
    delete(nodo);
}
