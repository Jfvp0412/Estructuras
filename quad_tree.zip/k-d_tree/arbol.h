#ifndef __ARBOL_H
#define __ARBOL_H

#include "nodo.h"
#include <queue>

template< class T >
struct Arbol
{
    Nodo<T> *raiz;
};

template< class T >
void crearArbol(Arbol<T> &tree, T val, T val2);

template< class T >
bool esVacio(Nodo<T> *inicio);

template< class T >
Nodo<T>* buscarNodoMay(Nodo<T> *inicio);

template< class T >
bool insertarNodo(Nodo<T> *inicio, T n, T n2, int dim);

template< class T >
bool eliminarNodo(Nodo<T> *inicio, Nodo<T> *anterior, T &n, T &n2, int dim);

template< class T >
bool buscar(Nodo<T> *inicio, T n, T n2, int dim);

template< class T >
void nivelOrden(Nodo<T> *inicio);

#include "arbol.hxx"

#endif
