#ifndef __GRAFO_H
#define __GRAFO_H

#include <stdlib.h>
#include <iostream>
#include <vector>
#include <queue>
#include <deque>

using namespace std;

template <class T>
struct Aux
{
    T dato;
    int peso;
};

template <class T>
struct Aux2
{
    T datoS;
    T datoF;
    int peso;
};

template <class T>
struct Grafo
{
    vector<T> vertices;
    vector< vector< Aux<T> > > aristas;
};

template <class T>
bool insertarVertice(Grafo<T> &grafo, T dato);

template <class T>
bool insertarArista(Grafo<T> &grafo, T datoS, T datoF, int peso);

template <class T>
bool eliminarVertice(Grafo<T> &grafo, T dato);

template <class T>
bool eliminarArista(Grafo<T> &grafo, T datoS, T datoF);

template <class T>
bool buscarVertice(Grafo<T> grafo, T dato);

template <class T>
bool buscarArista(Grafo<T> grafo, T datoS, T datoF);

template <class T>
int cantidadVertices(Grafo<T> grafo);

template <class T>
int cantidadAristas(Grafo<T> grafo);

template <class T>
bool esVacio(Grafo<T> grafo);

template <class T>
void recorridoProfundidad(Grafo<T> grafo, T verticeOrigen, vector<T> &visitados);

template <class T>
void recorridoAnchura(Grafo<T> grafo, T verticeOrigen, vector<T> visitados);

template <class T>
int componentesConectados(Grafo<T> grafo, T verticeOrigen);

template <class T>
void aristasPuente(Grafo<T> grafo, T verticeOrigen, vector<Aux2 <T> > &aristasPuente);

template <class T>
void caminoEuler(Grafo<T> grafo, T verticeOrigen);

template <class T>
void algoritmoFleury(Grafo<T> grafo, T verticeOrigen, vector<Aux2 <T> > &visitados, vector<Aux2 <T> > aristasPuente);

template <class T>
void algoritmoPrim(Grafo<T> grafo, T verticeOrigen);

template <class T>
void algoritmoDijkstra(Grafo<T> grafo, T verticeOrigen);

template <class T>
T buscarMenor(deque<T> q, vector<int> dist, vector<bool> &vivoQ);

#endif
