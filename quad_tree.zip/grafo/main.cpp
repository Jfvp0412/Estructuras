#include "grafo.h"
#include <iostream>

using namespace std;

int main()
{
    Grafo<int> grafo;
}
