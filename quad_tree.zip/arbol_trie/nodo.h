#ifndef __NODO_H
#define __NODO_H

#include <iostream>

using namespace std;

struct Nodo
{
    bool fin;//true si representa el final de una palabra
    Nodo *hijos[26];
};

Nodo *obtenerNodo();
void insertarPalabra(Nodo *raiz, string palabra);
bool buscar(Nodo *raiz, string palabra);

#endif
