//g++ -std=c++11 -o exe main.cpp
#include "nodo.h"

using namespace std;

int main()
{
    Nodo *raiz = obtenerNodo();
    /*string palabras[] = {"the", "a", "there", "answer", "any", "by", "bye", "their" };
    int n = sizeof(palabras)/sizeof(palabras[0]);

    for (int i = 0; i < n; i++)
    {
        insertarPalabra(raiz, palabras[i]);
    }

    if(buscar(raiz, "these"))
    {
        cout << "esta\n";
    }
    else
    {
        cout << "no esta\n";
    }*/

    insertarPalabra(raiz, "hola");
    insertarPalabra(raiz, "i");

    return 0;
}
