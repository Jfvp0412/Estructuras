#include "nodo.h"

Nodo *obtenerNodo()
{
    Nodo *nuevo = new Nodo();
    nuevo->fin = false;

    for (int i = 0; i < 26; i++)
    {
        nuevo->hijos[i] = NULL;
    }

    return nuevo;
}

void insertarPalabra(Nodo *raiz, string palabra)
{
    Nodo *arrastrar = raiz;

    for (int i = 0; i < palabra.length(); i++)
    {
        int indice = palabra[i] - 'a';

        if (!arrastrar->hijos[indice])//==NULL
        {
          std::cout << "/* message */" << '\n';
            arrastrar->hijos[indice] = obtenerNodo();
        }

        arrastrar = arrastrar->hijos[indice];
    }

    arrastrar->fin = true;
}

bool buscar(Nodo *raiz, string palabra)
{
    Nodo *arrastrar = raiz;
    cout << palabra << endl;

    for (int i = 0; i < palabra.length(); i++)
    {
        int indice = palabra[i] - 'a';
        cout << indice << " " << palabra[i] << endl;

        if (!arrastrar->hijos[indice])
        {
            return false;
        }

        arrastrar = arrastrar->hijos[indice];
    }

    return (arrastrar != NULL && arrastrar->fin);
}
