#include "arbol.h"

template< class T >
void crearArbol(Arbol<T> &tree, T val)
{
    tree.raiz = new Nodo<T>();
    tree.raiz->dato = val;
    tree.raiz->left = NULL;
    tree.raiz->right = NULL;
}

template< class T >
bool esVacio(Nodo<T> *inicio)
{
    return inicio == NULL;
}

template< class T >
bool insertarLeftNodo(Nodo<T> *inicio, T padre, T n)
{
    if (!esVacio(inicio))
    {
        if (inicio->left == NULL && inicio->right == NULL)
        {
            if (inicio->dato == padre)
            {
                insetarLeft(inicio, n);
                return true;
            }
        }
        else
        {
            bool sw = 0;

            if (inicio->dato == padre)
            {
                insetarLeft(inicio, n);
                return true;
            }

            if (inicio->left != NULL)
            {

                sw = insertarLeftNodo(inicio->left, padre, n);
            }
            if (inicio->right != NULL)
            {

                sw = insertarLeftNodo(inicio->right, padre, n);
            }

            return sw;
        }
    }
}

template< class T >
bool insertarRightNodo(Nodo<T> *inicio, T padre, T n)
{
    if (!esVacio(inicio))
    {
        if (inicio->left == NULL && inicio->right == NULL)
        {
            if (inicio->dato == padre)
            {
                insertarRight(inicio, n);
                return true;
            }
        }
        else
        {
            bool sw = 0;

            if (inicio->dato == padre)
            {
                insertarRight(inicio, n);
                return true;
            }

            if (inicio->left != NULL)
            {

                sw = insertarRightNodo(inicio->left, padre, n);
            }
            if (inicio->right != NULL)
            {

                sw = insertarRightNodo(inicio->right, padre, n);
            }

            return sw;
        }
    }
}

template< class T >
bool eliminarNodo(Nodo<T> *inicio, Nodo<T> *anterior, T &n)
{
    if (!esVacio(inicio))
    {
        if (inicio->left == NULL && inicio->right == NULL)
        {
            if (inicio->dato == n)
            {
                if (anterior->left != NULL)
                {
                    if (anterior->left->dato == n)
                    {
                        anterior->left = NULL;
                    }
                    else
                    {
                        anterior->right = NULL;
                    }
                }
                else if (anterior->right != NULL)
                {
                    if (anterior->right->dato == n)
                    {
                        anterior->right = NULL;
                    }
                    else
                    {
                        anterior->left = NULL;
                    }
                }

                eliminar(inicio);
                return true;
            }
        }
        else
        {
            bool sw = 0;

            if (inicio->dato == n)
            {
                if (anterior->left != NULL)
                {
                    if (anterior->left->dato == n)
                    {
                        anterior->left = NULL;
                    }
                    else
                    {
                        anterior->right = NULL;
                    }
                }
                else if (anterior->right != NULL)
                {
                    if (anterior->right->dato == n)
                    {
                        anterior->right = NULL;
                    }
                    else
                    {
                        anterior->left = NULL;
                    }
                }

                eliminar(inicio);
                return true;
            }
            if (inicio->left != NULL)
            {

                sw = eliminarNodo(inicio->left, inicio, n);
            }
            if (inicio->right != NULL)
            {

                sw = eliminarNodo(inicio->right, inicio, n);
            }

            return sw;
        }
    }
}

int cont = 1;
template< class T >
bool buscar(Nodo<T> *inicio, T n, Nodo<T> *raiz)
{
    if (!esVacio(inicio))
    {
        if (inicio->left == NULL && inicio->right == NULL)
        {
            //std::cout << "estoy en el llamado " <<  cont << " mi dato es " << inicio->dato <<'\n';
            cont++;
            int tam = 0;
            tamano(raiz, tam);

            if (inicio->dato == n)
            {
                cont = 1;
                return true;
            }
            else if (cont-1 == tam)
            {
                cont = 1;
                return false;
            }
        }
        else
        {
            //std::cout << "estoy en el llamado " <<  cont << " mi dato es " << inicio->dato <<'\n';
            cont++;
            bool sw = 0;

            if (inicio->dato == n)
            {
                cont = 1;
                return true;
            }
            if (inicio->left != NULL)
            {

                sw = buscar(inicio->left, n, raiz);
            }
            if (inicio->right != NULL)
            {

                sw = buscar(inicio->right, n, raiz);
            }

            return sw;
        }
    }
}

template< class T >
unsigned int altura(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        if (inicio->left == NULL && inicio->right == NULL)
        {
            return -1;
        }
        else
        {
            int max = 0, max2 = 0;

            if (inicio->left != NULL)
            {
                max = altura(inicio->left);
            }
            if (inicio->right != NULL)
            {

                max2 = altura(inicio->right);
            }
            if (max > max2)
            {
                return max + 1;
            }
            else
            {
                return max2 + 1;
            }
        }
    }
}

template< class T >
void tamano(Nodo<T> *inicio, int &tam)
{
    if (!esVacio(inicio))
    {
        if (inicio->left == NULL && inicio->right == NULL)
        {
            tam++;
        }
        else
        {
            tam++;

            if (inicio->left != NULL)
            {

                tamano(inicio->left, tam);
            }
            if (inicio->right != NULL)
            {

                tamano(inicio->right, tam);
            }
        }
    }
}

template< class T >
void preOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        if (inicio->left == NULL && inicio->right == NULL)
        {
            cout << inicio->dato << '\n';
        }
        else
        {
            cout << inicio->dato << '\n';

            if (inicio->left != NULL)
            {

                preOrden(inicio->left);
            }
            if (inicio->right != NULL)
            {
                preOrden(inicio->right);
            }
        }
    }
}

template< class T >
void posOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        if (inicio->left == NULL && inicio->right == NULL)
        {
            cout << inicio->dato << '\n';
        }
        else
        {
            if (inicio->left != NULL)
            {

                posOrden(inicio->left);
            }
            if (inicio->right != NULL)
            {
                posOrden(inicio->right);
            }

            cout << inicio->dato << '\n';
        }
    }
}

template< class T >
void nivelOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        queue<Nodo<T>*> q;
        q.push(inicio);

        while (!q.empty())
        {
              Nodo<T> *temp = q.front();
              q.pop();
              cout << temp->dato << '\n';

              if (temp->left != NULL)
              {
                  q.push(temp->left);
              }
              if (temp->right != NULL)
              {
                  q.push(temp->right);
              }
        }
    }
}
