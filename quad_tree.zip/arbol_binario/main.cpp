//g++ -std=c++11 -o hola main.cpp
#include <iostream>
#include "arbol.h"

using namespace std;

int main()
{
    Arbol<int> tree;
    tree.raiz = NULL;
    crearArbol(tree, 7);

    insertarLeftNodo(tree.raiz, 7, 3);
    insertarRightNodo(tree.raiz, 7, 20);
    insertarLeftNodo(tree.raiz, 3, 0);
    insertarRightNodo(tree.raiz, 3, 5);
    insertarLeftNodo(tree.raiz, 20, 15);
    insertarRightNodo(tree.raiz, 20, 25);
    insertarLeftNodo(tree.raiz, 0, -3);
    insertarRightNodo(tree.raiz, 0, 1);
    insertarLeftNodo(tree.raiz, 5, 4);
    insertarRightNodo(tree.raiz, 5, 6);
    insertarRightNodo(tree.raiz, 25, 30);
}
