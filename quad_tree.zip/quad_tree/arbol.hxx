#include "arbol.h"

void crearArbol(Arbol &tree, int val, int val2)
{
    tree.raiz = new Nodo();
    tree.raiz->dato = val;
    tree.raiz->dato2 = val2;
    tree.raiz->desc = NULL;
    tree.raiz->desc2 = NULL;
    tree.raiz->desc3 = NULL;
    tree.raiz->desc4 = NULL;
}

bool esVacio(Nodo *inicio)
{
    return inicio == NULL;
}

bool insertarNodo(Nodo *inicio, int val, int val2)
{
    if (!esVacio(inicio))
    {
        if (val < inicio->dato && val2 > inicio->dato2)
        {
            if (inicio->desc != NULL)
            {
                insertarNodo(inicio->desc, val, val2);
            }
            else
            {
                adicionarDesc(inicio, val, val2, 1);
                return true;
            }
        }
        else if (val > inicio->dato && val2 > inicio->dato2)
        {
            if (inicio->desc2 != NULL)
            {
                insertarNodo(inicio->desc2, val, val2);
            }
            else
            {
                adicionarDesc(inicio, val, val2, 2);
                return true;
            }
        }
        else if (val < inicio->dato && val2 < inicio->dato2)
        {
            if (inicio->desc3 != NULL)
            {
                insertarNodo(inicio->desc3, val, val2);
            }
            else
            {
                adicionarDesc(inicio, val, val2, 3);
                return true;
            }
        }
        else if (val > inicio->dato && val2 < inicio->dato2)
        {
            if (inicio->desc4 != NULL)
            {
                insertarNodo(inicio->desc4, val, val2);
            }
            else
            {
                adicionarDesc(inicio, val, val2, 4);
                return true;
            }
        }
    }

    return false;
}

void preOrden(Nodo *inicio)
{
    if (!esVacio(inicio))
    {
        cout << inicio->dato << " " << inicio->dato2 << '\n';
        preOrden(inicio->desc);
        preOrden(inicio->desc2);
        preOrden(inicio->desc3);
        preOrden(inicio->desc4);
    }
}

void posOrden(Nodo *inicio)
{
    if (!esVacio(inicio))
    {
        posOrden(inicio->desc);
        posOrden(inicio->desc2);
        posOrden(inicio->desc3);
        posOrden(inicio->desc4);
        cout << inicio->dato << " " << inicio->dato2 << '\n';
    }
}

void nivelOrden(Nodo *inicio)
{
    if (!esVacio(inicio))
    {
        queue<Nodo*> q;
        q.push(inicio);

        while (!q.empty())
        {
            Nodo *temp = q.front();
            q.pop();
            cout << temp->dato << " " << temp->dato2 << '\n';

            if (temp->desc != NULL)
            {
                q.push(temp->desc);
            }
            if (temp->desc2 != NULL)
            {
                q.push(temp->desc2);
            }
            if (temp->desc3 != NULL)
            {
                q.push(temp->desc3);
            }
            if (temp->desc4 != NULL)
            {
                q.push(temp->desc4);
            }
        }
    }
}
