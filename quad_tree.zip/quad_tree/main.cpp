//g++ -std=c++11 -o hola main.cpp
#include <iostream>
#include "arbol.h"

using namespace std;

int main()
{
    Arbol tree;
    tree.raiz = NULL;
    crearArbol(tree, 35, 40);

    insertarNodo(tree.raiz, 50, 10);
    insertarNodo(tree.raiz, 60, 75);
    insertarNodo(tree.raiz, 80, 65);
    insertarNodo(tree.raiz, 85, 15);
    insertarNodo(tree.raiz, 5, 45);
    insertarNodo(tree.raiz, 25, 35);
    insertarNodo(tree.raiz, 90, 5);

    nivelOrden(tree.raiz);
    std::cout << "/* message */" << '\n';
    preOrden(tree.raiz);
    std::cout << "/* message */" << '\n';
    posOrden(tree.raiz);
}
