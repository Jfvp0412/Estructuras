#include "nodo.h"

void adicionarDesc(Nodo *nodo, int nval, int nval2, int pos)
{
    Nodo *nuevo = new Nodo();
    nuevo->dato = nval;
    nuevo->dato2 = nval2;
    nuevo->desc = NULL;
    nuevo->desc2 = NULL;
    nuevo->desc3 = NULL;
    nuevo->desc4 = NULL;

    if (pos == 1)
    {
        nodo->desc = nuevo;
    }
    else if (pos == 2)
    {
        nodo->desc2 = nuevo;
    }
    else if (pos == 3)
    {
        nodo->desc3 = nuevo;
    }
    else if (pos == 4)
    {
        nodo->desc4 = nuevo;
    }
}
