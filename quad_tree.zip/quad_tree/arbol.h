#ifndef __ARBOL_H
#define __ARBOL_H

#include "nodo.h"
#include <queue>

struct Arbol
{
    Nodo *raiz;
};

void crearArbol(Arbol &tree, int val, int val2);

bool esVacio(Nodo *inicio);

bool insertarNodo(Nodo *inicio, int val, int val2);

void preOrden(Nodo *inicio);

void nivelOrden(Nodo *inicio);

#include "arbol.hxx"

#endif
