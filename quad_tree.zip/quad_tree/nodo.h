#ifndef __NODO_H
#define __NODO_H

using namespace std;

struct Nodo
{
    int dato;
    int dato2;
    Nodo *desc;
    Nodo *desc2;
    Nodo *desc3;
    Nodo *desc4;
};

void adicionarDesc(Nodo *nodo, int nval, int nval2, int pos);

#include "nodo.hxx"

#endif
