#ifndef __NODO_H
#define __NODO_H

#include <stdlib.h>

using namespace std;

template< class T >
struct Nodo
{
    T dato;
    Nodo<T> *left;
    Nodo<T> *right;
};

template< class T >
void insetarLeft(Nodo<T> *nodo, T nval);

template< class T >
void insertarRight(Nodo<T> *nodo, T nval);

template< class T >
void eliminar(Nodo<T> *nodo);

#include "nodo.hxx"

#endif
