#include "arbol.h"

template< class T >
void crearArbol(Arbol<T> &tree, T val)
{
    tree.raiz = new Nodo<T>();
    tree.raiz->dato = val;
    tree.raiz->left = NULL;
    tree.raiz->right = NULL;
}

template< class T >
bool esVacio(Nodo<T> *inicio)
{
    return inicio == NULL;
}

template< class T >
Nodo<T>* buscarNodoMay(Nodo<T> *inicio)
{
    Nodo<T> *may = NULL, *aux = inicio;

    while (aux != NULL)
    {
        may = aux;
        aux = aux->right;
    }

    return may;
}

template< class T >
bool insertarNodo(Nodo<T> *inicio, T n)
{
    if (!esVacio(inicio))
    {
        if (inicio->dato == n)
        {
            return false;
        }
        else if (n < inicio->dato)
        {
            if (inicio->left == NULL)
            {
                insetarLeft(inicio, n);
                return true;
            }
            else
            {
                return insertarNodo(inicio->left, n);
            }
        }
        else
        {
            if (inicio->right == NULL)
            {
                insertarRight(inicio, n);
                return true;
            }
            else
            {
                return insertarNodo(inicio->right, n);
            }
        }
    }
}

template< class T >
bool eliminarNodo(Nodo<T> *inicio, Nodo<T> *anterior, T &n)
{
    if (!esVacio(inicio))
    {
        if (inicio->dato == n)
        {
            if (inicio->left == NULL && inicio->right == NULL)
            {
                if (anterior->left != NULL)
                {
                    if (anterior->left->dato == n)
                    {
                        anterior->left = NULL;
                    }
                    else
                    {
                        anterior->right = NULL;
                    }
                }
                else if (anterior->right != NULL)
                {
                    if (anterior->right->dato == n)
                    {
                        anterior->right = NULL;
                    }
                    else
                    {
                        anterior->left = NULL;
                    }
                }

                eliminar(inicio);
                return true;
            }
            else if (inicio->left != NULL && inicio->right != NULL)
            {
                Nodo<T> *may = buscarNodoMay(inicio->left);
                int temp = may->dato;
                eliminarNodo(anterior, anterior, temp);
                inicio->dato = temp;
                return true;
            }
            else
            {
                if (inicio->left != NULL)
                {
                    int temp = inicio->left->dato;
                    inicio->dato = temp;
                    inicio->left = NULL;
                    return true;
                }
                else
                {
                    int temp = inicio->right->dato;
                    inicio->dato = temp;
                    inicio->right = NULL;
                    return true;
                }
            }
        }
        else if (n < inicio->dato)
        {
            if (inicio->left != NULL)
            {
                return eliminarNodo(inicio->left, inicio, n);
            }

        }
        else
        {
            if (inicio->right != NULL)
            {
                return eliminarNodo(inicio->right, inicio, n);
            }
        }
    }

    return false;
}

template< class T >
bool buscar(Nodo<T> *inicio, T n)
{
    if (!esVacio(inicio))
    {
        if (inicio->dato == n)
        {
            return true;
        }
        else if (n < inicio->dato)
        {
            if (inicio->left != NULL)
            {
                return buscar(inicio->left, n);
            }
        }
        else
        {
            if (inicio->right != NULL)
            {
                return buscar(inicio->right, n);
            }
        }
    }

    return false;
}

template< class T >
unsigned int altura(Nodo<T> *inicio)
{
    if (esVacio(inicio))
    {
        return -1;
    }
    else
    {
        int maxLeft = altura(inicio->left), maxRight = altura(inicio->right);

        if (maxLeft>maxRight)
        {
            return maxLeft + 1;
        }
        else
        {
            return maxRight + 1;
        }
    }
}

template< class T >
void tamano(Nodo<T> *inicio, int &tam)
{
    if (!esVacio(inicio))
    {
        tam++;
        tamano(inicio->left, tam);
        tamano(inicio->right, tam);
    }
}

template< class T >
void preOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        cout << inicio->dato << '\n';
        preOrden(inicio->left);
        preOrden(inicio->right);
    }
}

template< class T >
void posOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        posOrden(inicio->left);
        posOrden(inicio->right);
        cout << inicio->dato << '\n';
    }
}

template< class T >
void inOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        inOrden(inicio->left);
        cout << inicio->dato << '\n';
        inOrden(inicio->right);
    }
}

template< class T >
void nivelOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        queue<Nodo<T>*> q;
        q.push(inicio);

        while (!q.empty())
        {
              Nodo<T> *temp = q.front();
              q.pop();
              cout << temp->dato << '\n';

              if (temp->left != NULL)
              {
                  q.push(temp->left);
              }
              if (temp->right != NULL)
              {
                  q.push(temp->right);
              }
        }
    }
}
