#ifndef __NODO_H
#define __NODO_H

#include <stdlib.h>
#include <vector>

using namespace std;

template< class T >
struct Nodo
{
    T dato;
    vector <Nodo<T>*> desc;
};

template< class T >
void limpiarLista(Nodo<T> *nodo);

template< class T >
void adicionarDesc(Nodo<T> *nodo, T nval);

template< class T >
void eliminarDesc(Nodo<T> *nodo, T &val);

#include "nodo.hxx"

#endif
