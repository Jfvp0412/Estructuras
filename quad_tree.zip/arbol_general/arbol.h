#ifndef __ARBOL_H
#define __ARBOL_H

#include "nodo.h"
#include <queue>

template< class T >
struct Arbol
{
    Nodo<T> *raiz;
};

template< class T >
void crearArbol(Arbol<T> &tree, T val);

template< class T >
bool esVacio(Nodo<T> *inicio);

template< class T >
bool insertarNodo(Nodo<T> *inicio, T padre, T n);//me falta si lo inserta o no, pero si adiciona

template< class T >
bool eliminarNodo(Nodo<T> *inicio, Nodo<T> *anterior, T &n);//me falta si lo elimina o no, pero si elemina

template< class T >
bool buscar(Nodo<T> *inicio, T n, Nodo<T> *raiz);

template< class T >
unsigned int altura(Nodo<T> *inicio);

template< class T >
void tamano(Nodo<T> *inicio, int &tam);

template< class T >
void preOrden(Nodo<T> *inicio);

template< class T >
void posOrden(Nodo<T> *inicio);

template< class T >
void nivelOrden(Nodo<T> *inicio);

#include "arbol.hxx"

#endif
