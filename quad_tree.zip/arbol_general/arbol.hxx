#include "arbol.h"

template< class T >
void crearArbol(Arbol<T> &tree, T val)
{
    tree.raiz = new Nodo<T>();
    tree.raiz->dato = val;
}

template< class T >
bool esVacio(Nodo<T> *inicio)
{
    return inicio == NULL;
}

template< class T >
bool insertarNodo(Nodo<T> *inicio, T padre, T n)
{
    if (!esVacio(inicio))
    {
        if (inicio->desc.empty())
        {
            if (inicio->dato == padre)
            {
                adicionarDesc(inicio, n);
                return true;
            }
        }
        else
        {
            bool sw = 0;

            if (inicio->dato == padre)
            {
                adicionarDesc(inicio, n);
                return true;
            }

            for (int i = 0; i < inicio->desc.size(); i++)
            {
                sw = insertarNodo(inicio->desc[i], padre, n);
            }

            return sw;
        }
    }
}

template< class T >
bool eliminarNodo(Nodo<T> *inicio, Nodo<T> *anterior, T &n)
{
    if (!esVacio(inicio))
    {
        if (inicio->desc.empty())
        {
            if (inicio == anterior)
            {
                delete(inicio);
                inicio = NULL;
                delete(anterior);
                anterior = NULL;
                return true;
            }
            if (inicio->dato == n)
            {
                eliminarDesc(anterior, n);
                return true;
            }
        }
        else
        {
            bool sw = 0;

            if (inicio->dato == n)
            {
                eliminarDesc(anterior, n);
                return true;
            }

            for (int i = 0; i < inicio->desc.size(); i++)
            {
                sw = eliminarNodo(inicio->desc[i], inicio, n);
            }

            return sw;
        }
    }
}

int cont = 1;
template< class T >
bool buscar(Nodo<T> *inicio, T n, Nodo<T> *raiz)
{
    if (!esVacio(inicio))
    {
        if (inicio->desc.empty())
        {
            //std::cout << "estoy en el llamado " <<  cont << " mi dato es " << inicio->dato <<'\n';
            cont++;
            int tam = 0;
            tamano(raiz, tam);

            if (inicio->dato == n)
            {
                cont = 1;
                return true;
            }
            else if (cont-1 == tam)
            {
                cont = 1;
                return false;
            }
        }
        else
        {
            //std::cout << "estoy en el llamado " <<  cont << " mi dato es " << inicio->dato <<'\n';
            cont++;
            bool sw = 0;

            if (inicio->dato == n)
            {
                cont = 1;
                return true;
            }

            for (int i = 0; i < inicio->desc.size(); i++)
            {
                sw = buscar(inicio->desc[i], n, raiz);
            }

            return sw;
        }
    }
}

template< class T >
unsigned int altura(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        if (inicio->desc.empty())
        {
            return 0;
        }
        else
        {
            int max = 0, max2 = 0;

            for (int i = 0; i < inicio->desc.size(); i++)
            {
                max2 = altura(inicio->desc[i]);

                if (max2 > max)
                {
                    max = max2;
                }
            }

            return max + 1;
        }
    }
}

template< class T >
void tamano(Nodo<T> *inicio, int &tam)
{
    if (!esVacio(inicio))
    {
        if (inicio->desc.empty())
        {
            tam++;
        }
        else
        {
            tam++;

            for (int i = 0; i < inicio->desc.size(); i++)
            {
                tamano(inicio->desc[i], tam);
            }
        }
    }
}

template< class T >
void preOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        if (inicio->desc.empty())
        {
            cout << inicio->dato << '\n';
        }
        else
        {
            cout << inicio->dato << '\n';

            for (int i = 0; i < inicio->desc.size(); i++)
            {
                preOrden(inicio->desc[i]);
            }
        }
    }
}

template< class T >
void posOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        if (inicio->desc.empty())
        {
            cout << inicio->dato << '\n';
        }
        else
        {
            for (int i = 0; i < inicio->desc.size(); i++)
            {
                posOrden(inicio->desc[i]);
            }

            cout << inicio->dato << '\n';
        }
    }
}

template< class T >
void nivelOrden(Nodo<T> *inicio)
{
    if (!esVacio(inicio))
    {
        queue<Nodo<T>*> q;
        q.push(inicio);

        while (!q.empty())
        {
              Nodo<T> *temp = q.front();
              q.pop();
              cout << temp->dato << '\n';

              for (int i = 0; i < temp->desc.size(); i++)
              {
                  q.push(temp->desc[i]);
              }
        }
    }
}
