#include "nodo.h"

template< class T >
void limpiarLista(Nodo<T> *nodo)
{
    nodo->desc.clear();
}

template< class T >
void adicionarDesc(Nodo<T> *nodo, T nval)
{
    Nodo<T> *nuevo = new Nodo<T>();
    nuevo->dato = nval;
    nodo->desc.push_back(nuevo);
}

template< class T >
void eliminarDesc(Nodo<T> *nodo, T& val)
{
    for (int i = 0; i < nodo->desc.size(); i++)
    {
        if ((nodo->desc[i])->dato == val)
        {
            nodo->desc.erase(nodo->desc.begin()+i);
            return;
        }
    }
}
