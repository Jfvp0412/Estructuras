//g++ -std=c++11 -o hola main.cpp
#include <iostream>
#include "arbol.h"

using namespace std;

int main()
{
    Arbol<int> tree;
    tree.raiz = NULL;
    crearArbol(tree, 7);

    insertarNodo(tree.raiz, 7, 3);
    insertarNodo(tree.raiz, 7, 20);
    insertarNodo(tree.raiz, 3, 0);
    insertarNodo(tree.raiz, 3, 5);
    insertarNodo(tree.raiz, 20, 15);
    insertarNodo(tree.raiz, 20, 25);
    insertarNodo(tree.raiz, 0, -3);
    insertarNodo(tree.raiz, 0, 1);
    insertarNodo(tree.raiz, 5, 4);
    insertarNodo(tree.raiz, 5, 6);
    insertarNodo(tree.raiz, 25, 30);
}
